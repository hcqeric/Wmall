let s1 = document.getElementById("state1");
let s2 = document.getElementById("state2");

s1.onclick = function () {
  s1.style.display = 'none'
  s2.style.display = 'block'
}

s2.onclick = function () {
  s1.style.display = 'block'
  s2.style.display = 'none'
}